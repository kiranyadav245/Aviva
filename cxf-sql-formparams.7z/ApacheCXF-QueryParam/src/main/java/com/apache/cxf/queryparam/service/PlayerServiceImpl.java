package com.apache.cxf.queryparam.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.ws.rs.core.Response;

import org.springframework.stereotype.Service;


@Service("playerService")
public class PlayerServiceImpl implements IPlayerService {

	/**
	 * this method takes one argument from QueryParam and returns a Response
	 */
	public Response welcomePlayer(String playerName) {

		String greetMessage = "Welcome " + playerName + " to Lords - the home of cricket";
		return Response.status(200).entity(greetMessage).build();
	}
	
	public Response insert(String playerName,String playerName2) {

		String greetMessage = "values inserted  name1:" + playerName + " , name2 "+playerName2;
		
		Connection connection = MySqlDao.getConnection();
		try {
			Statement statement = connection.createStatement();
			String Query = "insert into student values("+1+",'"+playerName+playerName2+"')";
			statement.executeUpdate(Query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Response.status(200).entity(greetMessage).build();
	}
	
	public Response update(String playerName,String playerName2) {

		String greetMessage = "values updated  name1:" + playerName + " , name2 "+playerName2;
		Connection connection = MySqlDao.getConnection();
		try {
			Statement statement = connection.createStatement();
			String Query = "update student set name='"+playerName+playerName2+"'";
			statement.executeUpdate(Query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Response.status(200).entity(greetMessage).build();
	}
	
	public Response delete(String playerName,String playerName2) {
		Connection connection = MySqlDao.getConnection();
		try {
			Statement statement = connection.createStatement();
			String Query = "delete from student where name like '%"+playerName+"%' or name like '%"+playerName2+"%'";
			statement.executeUpdate(Query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String greetMessage = "values deleted  name1:" + playerName + " , name2 "+playerName2;
		return Response.status(200).entity(greetMessage).build();
	}
	

	/**
	 * this method takes three argument from QueryParam and returns a Response
	 */
	public Response getPlayerInfo(String playerName, int age, int matches) {

		String playerInfo = "[name=" + playerName +  ", age=" + age + ", matches=" + matches + "]";
		return Response.status(200).entity(playerInfo).build();
	}
	
}