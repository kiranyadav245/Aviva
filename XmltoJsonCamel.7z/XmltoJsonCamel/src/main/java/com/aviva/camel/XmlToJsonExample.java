package com.aviva.camel;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.model.dataformat.XmlJsonDataFormat;

public class XmlToJsonExample {

public static void main(String[] args) throws Exception {
		
		
		CamelContext context = new DefaultCamelContext();
		
		try {
			context.addRoutes(new RouteBuilder() {
				
				@Override
				public void configure() throws Exception {
					XmlJsonDataFormat xmlJsonFormat = new XmlJsonDataFormat();
					xmlJsonFormat.setEncoding("UTF-8");
					xmlJsonFormat.setForceTopLevelObject(true);
					from("file:src/data?noop=true").marshal(xmlJsonFormat).to("file:src/json");
				}
			});
			context.start();
			Thread.sleep(2*60*1000);
		} finally {
			context.stop();
		}
	}
}
