package com.cxf.service;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Component;
/**
 *  Access as http://localhost:8080/services/svc/ok
 * CXF Servlet by default mapped with 'services' path
 * @author kiran
 *
 */
@Path("/svc/")
@Component
@Produces(MediaType.TEXT_PLAIN)
public class HelloService {

    @Path("/say")
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String sayHello() {
        return "Hello World";
    }

    @Path("/ok")
    @GET
    public Response sayOk() {
        return Response.status(200).entity("ok").build();
    }
}