package com.cxf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CxfExamplesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CxfExamplesApplication.class, args);
	}
}
