package com.cxf.service;

import javax.ws.rs.FormParam;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

public class BeanParamVo {
	@PathParam("p")
	private String pathaparam;
	@FormParam("b")
	private String formparam;
	@MatrixParam("m")
	private String matrixparam;
	@QueryParam("d")
	private String queryparam;
	@HeaderParam("user-agent")
	private String headerpram;
	public String getPathaparam() {
		return pathaparam;
	}
	public void setPathaparam(String pathaparam) {
		this.pathaparam = pathaparam;
	}
	public String getFormparam() {
		return formparam;
	}
	public void setFormparam(String formparam) {
		this.formparam = formparam;
	}
	public String getMatrixparam() {
		return matrixparam;
	}
	public void setMatrixparam(String matrixparam) {
		this.matrixparam = matrixparam;
	}
	public String getQueryparam() {
		return queryparam;
	}
	public void setQueryparam(String queryparam) {
		this.queryparam = queryparam;
	}
	public String getHeaderpram() {
		return headerpram;
	}
	public void setHeaderpram(String headerpram) {
		this.headerpram = headerpram;
	}
	@Override
	public String toString() {
		return "BeanParamVo [pathaparam=" + pathaparam + ", formparam=" + formparam + ", matrixparam=" + matrixparam
				+ ", queryparam=" + queryparam + ", headerpram=" + headerpram + "]";
	}

}
