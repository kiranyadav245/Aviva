package com.cxf.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.List;

import javax.ws.rs.BeanParam;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.springframework.stereotype.Component;

/**
 * different types of URI matching
 * Access as http://localhost:8080/services/uri/??? where ??? is method path name
 * @author kiran
 *
 */
@Path("/uri")
@Component
public class URIService {
	
	@GET
	@Path("/get")
	public Response getUri(){
		return Response.status(200).entity("Normal URI with method GET").build();
	}
	
	@GET
	@Path("/{name}")
	public Response getURiPathParam(@PathParam("name")String name){
		return Response.status(200).entity("Path param URI with method GET. path param is name and its value is " + name ).build();
	}
	
	@GET
	@Path("{id : \\d+}") //support digit only
	public Response getUserById(@PathParam("id") String id) {

	   return Response.status(200).entity("getUserById is called, id : " + id).build();

	}

	@GET
	@Path("/kiran/{username}")
	public Response getUserByUserName(@PathParam("username") String username) {

	   return Response.status(200)
		.entity("getUserByUserName is called, username : " + username).build();
	}
	
	@GET
	@Path("/{year}/{month}/{day}")
	public Response getMltiPathParam(@PathParam("year")String year,@PathParam("month")String month,@PathParam("day")String day){
		return Response.status(200).entity("Multi Path param URI with method GET. path params are "  + year +":"+month+":"+ day ).build();
	}
	
	@GET
	@Path("/queryparam")
	public Response queryparam(@QueryParam("from") int from,
		@DefaultValue("256")@QueryParam("to") int to,
		@QueryParam("orderBy") List<String> orderBy){
		
		return Response.status(200).entity(""+from + to + orderBy).build();
		
	}
	
	@GET
	@Path("/query")
	public Response getUsers(@Context UriInfo info) {

		String from = info.getQueryParameters().getFirst("from");
		String to = info.getQueryParameters().getFirst("to");
		List<String> orderBy = info.getQueryParameters().get("orderBy");

		return Response
		   .status(200)
		   .entity("getUsers is called, from : " + from + ", to : " + to
			+ ", orderBy" + orderBy.toString()).build();

	}

	
	@GET
	@Path("/matrix")
	public Response matrix(@QueryParam("name")String name,
							@MatrixParam("id") int id){

			return Response
			   .status(200)
			   .entity("query param name :"+name+" matrix param id:"+id).build();

	}
	
	@POST
	@Path("/formparam")
	public Response formparam(@FormParam("name") String name){
		return Response.status(200).entity(name).build();
	}
	
	
	@GET
	@Path("/beanparam/{p}")
	public Response beanparam(@BeanParam BeanParamVo vo){
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/sonoo","root","root");  
			//here sonoo is database name, root is username and password  
			Statement stmt=con.createStatement();  
		}catch (Exception e) {
			// TODO: handle exception
		}
		return Response.status(200).entity("used @BeanParam" + vo.toString()).build();
	}
}
