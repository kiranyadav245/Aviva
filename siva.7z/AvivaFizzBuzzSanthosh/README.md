# Spring Boot Camel REST / SQL QuickStart

This example demonstrates AvivaFIZZBUZZ application

Implemted with spring boot and apache camel and swagger for documentation support

## Launch application

 application Launch is done with main program trigger Application,java
 
 Launched application can be access at http://localhost:8080/avivabuzz/
 
 Services Provided with
 		
 			1) full display of numbers at http://localhost:8080/avivabuzz/printInput/124
 			2) Display with Limited inputs at http://localhost:8080/avivabuzz/printLimitedInput/124?next=20&previous=100
 			
 this includes validations and other constraints implied as per the requirment	
 
 
 #JUNIT
 
 Junit not provided due to time constraints :(((		
 
 

### Swagger API & Documentation support

The example provides API documentation of the service using Swagger.

 You can access the API documentation from your Web browser at <http://qs-camel-rest-sql.vagrant.f8/camel-rest-sql/api-doc>.

http://localhost:8080/avivabuzz/api-doc

this JSON can be compilied with swagger-ui support and for generation of client stubs