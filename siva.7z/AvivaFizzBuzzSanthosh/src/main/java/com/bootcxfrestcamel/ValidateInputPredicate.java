package com.bootcxfrestcamel;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;

public class ValidateInputPredicate implements Predicate {

	@Override
	public boolean matches(Exchange exchange) {
		int userInput=exchange.getIn().getHeader("id",Integer.class);
		if(userInput<=1000&&userInput>=1)
			return true;
		else
			return false;
	}

}
