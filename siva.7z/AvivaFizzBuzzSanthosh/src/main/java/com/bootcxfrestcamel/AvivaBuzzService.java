/*
 * Copyright 2005-2016 Red Hat, Inc.
 *
 * Red Hat licenses this file to you under the Apache License, version
 * 2.0 (the "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 * implied.  See the License for the specific language governing
 * permissions and limitations under the License.
 */
package com.bootcxfrestcamel;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

@Component
public class AvivaBuzzService {
	
	public static final String FIZZ="FIZZ";
	public static final String BUZZ="BUZZ";
	public static final String FIZZ_BUZZ="FIZZ_BUZZ";
	
	/**
	 * ProcesInput helps in processing user inputs without limits
	 * @param exchange
	 */
	public void processInput(Exchange exchange)
	{
		int userInput=exchange.getIn().getHeader("id",Integer.class);
		//printUserInput(wrapDisplayContent(userInput,0,0,false));
		exchange.getIn().setBody(wrapDisplayContent(userInput,0,0,false));
		
	}
	
	
	/**
	 * processLimitedInput method provides service for displaying limited input based on "next" and "previous" contents
	 * @param exchange
	 */
	public void processLimitedInput(Exchange exchange)
	{
		int userInput=exchange.getIn().getHeader("id",Integer.class);
		
				if(exchange.getIn().getHeader("next",String.class)!=null 
					&& exchange.getIn().getHeader("previous",String.class)!=null)
					{	
						int next= exchange.getIn().getHeader("next",Integer.class);
						int previous= exchange.getIn().getHeader("next",Integer.class);
						
						//printUserInput(wrapDisplayContent(userInput,next,previous,true));
						if(next-previous<=20)
						{
							exchange.getIn().setBody(wrapDisplayContent(userInput,next,previous,true));
						}
						else
						{
							exchange.getIn().setBody("Please provide query params with NEXT & PREVIOUS inputs with differnce content for 20 display only");
						}
					}
					else
					{
						exchange.getIn().setBody("Please provide query params with NEXT & PREVIOUS inputs");
					}
		
	}
	
	
	public void printUserInput(List<String> displayContent)
	{
		for(String temp : displayContent)
		{
			System.out.println("console printValue -->"+temp);
		}
	}
	
	/**
	 * wrapDisplayContent helps in returning number value based on user inputs
	 * @param input
	 * @param nextlimit
	 * @param previousLimit
	 * @param limitFlag
	 * @return
	 */
	public List<String> wrapDisplayContent(int input,int nextlimit,int previousLimit,Boolean limitFlag)
	{
		List<String> loadVal= new ArrayList<String>();
		
		if(!limitFlag)
		{	
			for(int i=0; i<input; i++)
			{
				loadVal.add(checkFizzBuzz(i));
			}
		}
		else
		{
			for(int i=input-previousLimit,count=0; i<=input+nextlimit&&count<=20; i++)
			{
				loadVal.add(checkFizzBuzz(i));
				count++;
			}
		}
		return loadVal;
		
	}
	
	
	/**
	 * checkFizzBuzz method helps in applying FIZZ BUZZ logic
	 * @param num
	 * @return
	 */
	public String checkFizzBuzz(int num)
	{
		String returnVal=num+"";
		if(num>=15&&num%15==0)	
		{
			returnVal= FIZZ_BUZZ;
		}
		else
		if(num%5==0)
		{
			returnVal= FIZZ;
		}
		else
		if(num%3==0)
		{
			returnVal= BUZZ;
		}
		return returnVal;
	}

}
