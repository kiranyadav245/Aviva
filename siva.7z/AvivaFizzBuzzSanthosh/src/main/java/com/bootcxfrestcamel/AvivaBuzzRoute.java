package com.bootcxfrestcamel;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
@Component
public class AvivaBuzzRoute extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		
		
		 restConfiguration()
	         .contextPath("/avivabuzz").apiContextPath("/api-doc")
	             .apiProperty("api.title", "Aviava Buzz Service Implemntation")
	             .apiProperty("api.version", "1.0")
	             .apiProperty("cors", "true")
	             .apiContextRouteId("doc-api")
	         .component("servlet")
	         .bindingMode(RestBindingMode.json);

     rest("/testService").description("User Input Service for AvivaFizzBuzz")
         .get("/").description("The list of all the books")
             .route().routeId("userInputRoute")
             .transform().constant("HI SUCCESS SIVA").endRest();
     
     rest("/printInput/{id}").description("Print User Input Service for AvivaFizzBuzz")
	     .get("/").description("Prints the listed numbers").consumes("text/plain").produces("application/json")
	         .route().routeId("printUserInputRoute")
	         .choice()
	         	.when(new ValidateInputPredicate())
	         		.bean("avivaBuzzService","processInput")
	         	.otherwise()	
	         		.transform().constant("Please Enter number between 1 to 1000").endRest();
     
     rest("/printLimitedInput/{id}/").description("Print Limited User Input Service for AvivaFizzBuzz")
     .get("/").description("Prints the listed numbers").consumes("text/plain").produces("application/json")
         .route().routeId("printUserLimitedInputRoute")
         .choice()
         	.when(new ValidateInputPredicate())
         		.bean("avivaBuzzService","processLimitedInput")
         	.otherwise()	
         		.transform().constant("Please Enter number between 1 to 1000").endRest();
     
	}
	
	
}
