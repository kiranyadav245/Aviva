package com.test.services;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.junit.Before;
import org.junit.Test;

public class FizzBuzzServiceTest {

	FizzBuzzService is;
	String weekDay;

	@Before
	public void init() {
		is = new FizzBuzzService();
		weekDay = getDay();
	}

	@Test
	public void fizzbuzzNotRangeTest() {

		String fizzBuzz = is.fizzBuzz(0, 0);
		assertEquals("given input is out of range", fizzBuzz);

	}

	@Test
	public void fizzbuzzInputZeroTest() {
		String fizzBuzz = is.fizzBuzz(0, 0);
		assertEquals("given input is out of range", fizzBuzz);

	}

	@Test
	public void fizzbuzzInputValidInputTest() {
		String fizzBuzz = is.fizzBuzz(20, 0);
		assertNotEquals("given input is out of range", fizzBuzz);

	}

	@Test
	public void fizzbuzzNoWednesdayFizzTest() {
		String fizzBuzz = is.fizzBuzz(12, 0);
		if (!"WEDNESDAY".equalsIgnoreCase(weekDay)) {
			boolean contains = fizzBuzz.contains("fizz");
			assertEquals(true, contains);
		}
	}

	@Test
	public void fizzbuzzNoWednesdayBuzzTest() {
		String fizzBuzz = is.fizzBuzz(12, 0);
		if (!"WEDNESDAY".equalsIgnoreCase(weekDay)) {
			boolean contains = fizzBuzz.contains("buzz");
			assertEquals(true, contains);
		}
	}

	@Test
	public void fizzbuzzWednesdaywuzzTest() {
		String fizzBuzz = is.fizzBuzz(12, 0);
		if ("WEDNESDAY".equalsIgnoreCase(weekDay)) {
			boolean contains = fizzBuzz.contains("wuzz");
			assertEquals(true, contains);
		}
	}

	private String getDay() {
		Calendar calendar = Calendar.getInstance();
		Date date = calendar.getTime();
		String weekDay = new SimpleDateFormat("EEEE", Locale.ENGLISH).format(date.getTime());
		return weekDay;
	}

	@Test
	public void fizzbuzzWednesdayfizzTest() {
		String fizzBuzz = is.fizzBuzz(12, 0);
		String weekDay = getDay();
		if ("WEDNESDAY".equalsIgnoreCase(weekDay)) {
			boolean contains = fizzBuzz.contains("wizz");
			assertEquals(true, contains);
		}
	}

}
