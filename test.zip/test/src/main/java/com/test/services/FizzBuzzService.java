package com.test.services;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.springframework.stereotype.Service;
 
@Service
@Path("/fizzbuzz")
public class FizzBuzzService
{
    private static final String WEDNESDAY = "Wednesday";
	
	@GET
	@Path("/{input}")
	@Produces(MediaType.TEXT_HTML)
	public String fizzBuzz(@PathParam("input")int input,@QueryParam("start")int start){
		
		String op = "";
		String fizz = "fizz ";
		String buzz = "buzz ";
		Calendar calendar = Calendar.getInstance();
		Date date = calendar.getTime();
		String weekDay = new SimpleDateFormat("EEEE", Locale.ENGLISH).format(date.getTime());
		if(WEDNESDAY.equals(weekDay)){
			fizz = "wizz ";
			buzz = "wuzz ";
		}
		if(input>=1 && input <=1000){
			int index = 1;
			for (; index <= input; index++) {
				
				if (index % 3 == 0) {
					if (index % 5 == 0) {
						op = op + fizz + " " + buzz;
					} else {
						op = op + fizz;
					}
				} else if (index % 5 == 0) {
					op = op + buzz;
				} else {
					op = op +" "+ String.valueOf(index);
				}
			}
		}else{
			op = "given input is out of range";
		}
		return op;
	}
	
	@GET
	@Path("/page/{input}")
	@Produces(MediaType.TEXT_HTML)
	public String fizzBuzzPagination(@PathParam("input")int input,@QueryParam("start")int start){
		
		String op = "";
		String fizz = "fizz ";
		String buzz = "buzz ";
		Calendar calendar = Calendar.getInstance();
		Date date = calendar.getTime();
		String weekDay = new SimpleDateFormat("EEEE", Locale.ENGLISH).format(date.getTime());
		if(WEDNESDAY.equals(weekDay)){
			fizz = "wizz ";
			buzz = "wuzz ";
		}
		if(input>=1 && input <=1000){
			int index = 1;
			int max = 20;
			if(start<0)
				start = 0;
			int prevIndex = start-20;
			if(start != 0){
				index=start+1;
				max=start+max;
			}
			String prev = "";
			for (; index <= input; index++) {
				
				if(index > 20 && prev.isEmpty()){
					prev = "<a href='"+input+"?start="+prevIndex+"'>Prev</a><br />";
				}
				if (index % 3 == 0) {
					if (index % 5 == 0) {
						op = op +" '"+ fizz + buzz+"'";
					} else {
						op = op +" "+ fizz;
					}
				} else if (index % 5 == 0) {
					op = op +" "+ buzz;
				} else {
					op = op +" "+ String.valueOf(index);
				}
				if(index >=max ){
					if(!prev.isEmpty())
						op= prev + op;
					op = op+"<br />"+
							 "<a href='"+input+"?start="+index+"'>Next</a>";
					break;
				}
			}
		}else{
			op = "given input is out of range";
		}
		return op;
	}

}